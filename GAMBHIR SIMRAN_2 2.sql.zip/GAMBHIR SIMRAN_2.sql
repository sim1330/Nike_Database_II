
Question #1: 


WITH nike_orders AS (
  SELECT * FROM order_items
  UNION ALL
  SELECT * FROM order_items_vintage
)

SELECT
customers.state, COUNT(DISTINCT nike_orders.user_id) as total_customer
FROM
nike_orders
JOIN customers ON customers.customer_id = nike_orders.user_id
group by customers.state;


Question #2: 


WITH nike_official_orders AS (
  SELECT *FROM order_items
),
nike_vintage_orders AS (
  SELECT * FROM order_items_vintage
)

SELECT 
     CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(DISTINCT o.order_id) AS total_completed_orders

 
FROM
  orders o
 LEFT JOIN customers c ON c.customer_id = o.user_id

  WHERE
  o.status = 'Complete'
GROUP BY
  cleaned_state;


Question #3: 


WITH nike_official_orders AS (
  SELECT *FROM order_items
),
nike_vintage_orders AS (
  SELECT * FROM order_items_vintage
)

SELECT 
     CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(DISTINCT o.order_id) AS total_completed_orders,
  COUNT(DISTINCT official.order_id) AS official_completed_orders,
  COUNT(DISTINCT vintage.order_id) AS official_completed_orders
 
FROM
  orders o
  LEFT JOIN customers c ON c.customer_id = o.user_id
  LEFT JOIN nike_official_orders official ON o.order_id = official.order_id
  LEFT JOIN nike_vintage_orders vintage ON o.order_id = vintage.order_id
  WHERE
  o.status = 'Complete'
GROUP BY
  cleaned_state;


Question #4: 

WITH combined_table AS (
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  SUM(items.sale_price)as revenue FROM order_items items
  LEFT JOIN customers c ON c.customer_id = items.user_id
  group by items.order_item_id, c.customer_id
UNION ALL
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  SUM(vintage.sale_price)as revenue FROM order_items_vintage vintage
  LEFT JOIN customers c ON c.customer_id = vintage.user_id
  group by vintage.order_item_id, c.customer_id
) ,
completed as (
SELECT 
   CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(DISTINCT o.order_id) AS total_completed_orders,
  COUNT(DISTINCT items.order_id) AS official_completed_orders,
  COUNT(DISTINCT vintage.order_id) AS vintage_completed_orders

FROM orders o
  LEFT JOIN customers c ON c.customer_id = o.user_id
  LEFT JOIN order_items items ON items.order_id = o.order_id
  LEFT JOIN order_items_vintage vintage ON o.order_id = vintage.order_id
  WHERE
  o.status = 'Complete'
GROUP BY
  cleaned_state
)
SELECT
      completed.cleaned_state,
      completed.total_completed_orders,
      completed.official_completed_orders,
      completed.vintage_completed_orders,
      SUM(combined_table.revenue) AS total_revenue
FROM completed
full join combined_table ON completed.cleaned_state = combined_table.cleaned_state
GROUP BY 
    completed.cleaned_state, 
    completed.total_completed_orders,
    completed.vintage_completed_orders,
    completed.official_completed_orders;

Question #5: 


WITH combined_table AS (
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(CASE WHEN items.returned_at IS NOT NULL THEN 1 END) AS returned_items_count,
  SUM(items.sale_price)as revenue FROM order_items items
  LEFT JOIN customers c ON c.customer_id = items.user_id
  group by items.order_item_id, c.customer_id
UNION ALL
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(CASE WHEN vintage.returned_at IS NOT NULL THEN 1 END) AS returned_items_count,
  SUM(vintage.sale_price)as revenue FROM order_items_vintage vintage
  LEFT JOIN customers c ON c.customer_id = vintage.user_id
  group by vintage.order_item_id, c.customer_id
) ,
completed as (
SELECT 
   CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
 
  COUNT(DISTINCT o.order_id) AS total_completed_orders,
  COUNT(DISTINCT items.order_id) AS official_completed_orders,
  COUNT(DISTINCT vintage.order_id) AS vintage_completed_orders

FROM orders o
  LEFT JOIN customers c ON c.customer_id = o.user_id
  LEFT JOIN order_items items ON items.order_id = o.order_id
  LEFT JOIN order_items_vintage vintage ON o.order_id = vintage.order_id
  WHERE
  o.status = 'Complete'
GROUP BY
  cleaned_state, items.returned_at, vintage.returned_at
)
SELECT
      completed.cleaned_state,
      completed.total_completed_orders,
      completed.official_completed_orders,
      completed.vintage_completed_orders,
      SUM(combined_table.revenue) AS total_revenue,
      COUNT(CASE WHEN combined_table.returned_items_count  > 0 THEN 1 END) as returned_items_count
FROM completed
full join combined_table ON completed.cleaned_state = combined_table.cleaned_state
GROUP BY 
    
    completed.cleaned_state, 
    completed.total_completed_orders,
    completed.vintage_completed_orders,
    completed.official_completed_orders
   ;

Question #6: 


WITH combined_table AS (
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(CASE WHEN items.returned_at IS NOT NULL THEN 1 END) AS returned_items_count,
  COUNT(items.order_item_id) as total_order_items,
  SUM(items.sale_price)as revenue FROM order_items items
  LEFT JOIN customers c ON c.customer_id = items.user_id
  group by items.order_item_id, c.customer_id
UNION ALL
  SELECT *,  CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
  COUNT(CASE WHEN vintage.returned_at IS NOT NULL THEN 1 END) AS returned_items_count,
  COUNT(vintage.order_item_id) as total_order_items,
  SUM(vintage.sale_price)as revenue FROM order_items_vintage vintage
  LEFT JOIN customers c ON c.customer_id = vintage.user_id
  group by vintage.order_item_id, c.customer_id
) ,
completed as (
SELECT 
   CASE 
        WHEN c.state = 'US State' THEN 'California' 
        WHEN c.state IS NULL THEN 'missing data'
        ELSE c.state 
    END AS cleaned_state,
 
  COUNT(DISTINCT o.order_id) AS total_completed_orders,
  COUNT(DISTINCT items.order_id) AS official_completed_orders,
  COUNT(DISTINCT vintage.order_id) AS vintage_completed_orders

FROM orders o
  LEFT JOIN customers c ON c.customer_id = o.user_id
  LEFT JOIN order_items items ON items.order_id = o.order_id
  LEFT JOIN order_items_vintage vintage ON o.order_id = vintage.order_id
  WHERE
  o.status = 'Complete'
GROUP BY
  cleaned_state, items.returned_at, vintage.returned_at
)
SELECT
      completed.cleaned_state,
      completed.total_completed_orders,
      completed.official_completed_orders,
      completed.vintage_completed_orders,
      SUM(combined_table.revenue) AS total_revenue,
      COUNT(CASE WHEN combined_table.returned_items_count  > 0 THEN 1 END) as returned_items_count,
      SUM(combined_table.returned_items_count)/SUM(combined_table.total_order_items) as return_rate
FROM completed
full join combined_table ON completed.cleaned_state = combined_table.cleaned_state
GROUP BY 
    
    completed.cleaned_state, 
    completed.total_completed_orders,
    completed.vintage_completed_orders,
    completed.official_completed_orders
   ;
